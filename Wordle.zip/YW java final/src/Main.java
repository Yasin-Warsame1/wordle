
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.border.Border;

public class Main {

    //a list of all possible 5 letter words in English
    public static HashSet<String> dictionary = new HashSet<>();

    //a smaller list of words for selecting the target word from (i.e. the word the player needs to guess)
    public static ArrayList<String> targetWords = new ArrayList<>();

    public static void main(String[] args) {
        //load in the two word lists
        try {
            Scanner in_dict = new Scanner(new File("gameDictionary.txt"));
            while (in_dict.hasNext()) {
                dictionary.add(in_dict.next());
            }

            Scanner in_targets = new Scanner(new File("targetWords.txt"));
            while (in_targets.hasNext()) {
                targetWords.add(in_targets.next());
            }
            in_dict.close();
            in_targets.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        GUI();
    }

    //use this method for selecting a word. It's important for marking that the word you have selected is printed out to the console!
    public static String getTarget() {
        Random r = new Random();
        String target = targetWords.get(r.nextInt(targetWords.size()));
        //don't delete this line.
        System.out.println(target);
        return target;
    }

    //some variables to help through out the implementation
    static JLabel[][] text;
    static JLabel result;
    static int index;
    static String WORD;
    static boolean gameEnd = false;
    static JButton newGame;
    
    //method to implement the GUI and handle user actions
    public static void GUI() {
        //at the very beginning, display a pop up for user's help
        JOptionPane.showMessageDialog(null, "This is my own version of the game wordle where you have 6 trys \nto guess a 5 letter word using the help of the following colours \n"
                + "GREEN: If the letter is correct and at correct spot\n"
                + "LIGHT GRAY: If the letter is in the word but at wrong spot\n"
                + "CYAN: If the letter is not even a part of the word");
        index = 0;
        gameEnd = false;
        //get the target word
        WORD = getTarget();
        //convert it to upper case letters
        WORD = WORD.toUpperCase();
        //create a frame
        JFrame frame = new JFrame("Wordle");
        //create labels (one for each letter)
        text = new JLabel[6][5];
        //x and y coordinates to set the position of labels on the frame
        int x = 30;
        int y = 10;

        //make border around the labels (to make it look like the example picture given)
        Border border = BorderFactory.createLineBorder(Color.GRAY, 1);
        //set font for each guessed letter
        Font font = new Font("Verdana", Font.BOLD, 50); 

        //create labels for each index (above created labels array of 5x6)
        for (int a = 0; a < text.length; a++) {
            for (int b = 0; b < text[a].length; b++) {
                //initialise each label
                text[a][b] = new JLabel();
                //set its position on the frame
                text[a][b].setBounds(x, y, 60, 60);
                //set its font
                text[a][b].setFont(font);
                //set the color of letter
                text[a][b].setForeground(Color.BLACK);
                //set the color of background
                text[a][b].setOpaque(true);
                text[a][b].setBackground(Color.WHITE);
                //set border around the label (each letter)
                text[a][b].setBorder(border);
                //make the word in the center of the label (each letter in the center of the box)
                text[a][b].setHorizontalAlignment(JLabel.CENTER);
                text[a][b].setVerticalAlignment(JLabel.CENTER);
                //add each label to the frame
                frame.add(text[a][b]);
                x += 70;    //add 70 to x, (setting position for next coming labels)
            }
            //set the x and y coordinates for coming labels/boxes
            x = 30;
            y += 70;
        }

        //result label to announce whether you win or lose
        result = new JLabel("");    //empty label, we will add message to it when the player wins/loses
        //set its location on frame
        result.setBounds(0, 430, 400, 25);
        //set its font and font size
        result.setFont(new Font("Verdana", Font.BOLD, 15));
        //make is center
        result.setHorizontalAlignment(JLabel.CENTER);
        //add it to the frame
        frame.add(result);
        
        //button to start a new game
        newGame = new JButton("New Game");
        newGame.setEnabled(false);  //by default this button is disabled
        newGame.setBounds(150, 460, 100, 25);   //set button's location on the frame
        frame.add(newGame); //add button to frame
        //action listener for button click
        newGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when this buttn is clicked
                frame.dispose();    //dispose off the current frame
                GUI();  //start a completely new one
            }
        });
        //add key listener to frame so we can trace the keyboard button clicks
        frame.addKeyListener(new Listener());
        
        //set size of frame and its location on the PC screen
        frame.setSize(400, 550);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //make the frame visible to user
        frame.setVisible(true);
    }

    //inner private class to hanle the keyboard button clicks
    private static class Listener implements KeyListener {

        //when any button on keyboard is clicked, this method is called automatically
        @Override
        public void keyPressed(KeyEvent e) {
            if (!gameEnd) { //check if the game is not end yet
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {  //check if the ENTER button is pressed
                    boolean valid = true;
                    //enter key cannot work until all the 5 letters in one row are entered
                    for (int a = 0; a < text[index].length; a++) {
                        if (text[index][a].getText().equals("")) {  //check if there is even a single empty box
                            valid = false;  //set valid to false if empty box is found
                        }
                    }
                    if (valid) {    //if no empty box is found in the line (All letters are entered)
                        int matches = 0;
                        //check the entered letters in a for loop
                        for (int a = 0; a < text[index].length; a++) {
                            //if the letter is in the word AND at right spot
                            if (WORD.charAt(a) == text[index][a].getText().charAt(0)) {
                                //change the color of the box to green and letter color to white
                                text[index][a].setBackground(Color.GREEN);
                                text[index][a].setForeground(Color.WHITE);
                                matches++;  //increment matches
                            }//if the letter is in the word AND at wrong spot
                            else if (WORD.contains(text[index][a].getText())) {
                                //change the color of the box to light gray and letter color to white
                                text[index][a].setBackground(Color.LIGHT_GRAY);
                                text[index][a].setForeground(Color.WHITE);
                            } //if the letter is NOT in the word 
                            else if (!WORD.contains(text[index][a].getText())) {
                                //change the color of the box to cyan and letter color to white
                                text[index][a].setBackground(Color.CYAN);
                                text[index][a].setForeground(Color.WHITE);
                            }
                        }
                        //if 5 letters matched, it means the correct word has been guessed
                        if(matches == 5){
                            //set this varialbe to true to end the game
                            gameEnd = true;
                            //new Game button appears now
                            newGame.setEnabled(true);
                            //print a congrats message
                            result.setText("You Guessed It!");
                        }   
                        else if(index == 5){    //if 5 letters dont matche but al boxes are filled
                            //end the game
                            gameEnd = true;
                            //New Game button appears now
                            newGame.setEnabled(true);
                            //show the correct word to the user
                            result.setText("Correct Letter: "+WORD);
                        }
                        //every time ENTER is pressed, increment this varialbe
                        //just to keep record at which line number we are taking letters input from user
                        if (index < text.length) {
                            index++;
                        }
                    }
                }   //if back space button is pressed (remove the last entered letter)
                else if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                    for (int a = 0; a < text[index].length; a++) {
                        //if its the last letter in the row
                        if (a == text[index].length - 1) {
                            text[index][a].setText(""); //remove the letter and set the box to empty
                            return;
                        } //otherwise check the other boxes/labels
                        else if (text[index][a + 1].getText().equals("")) {
                            text[index][a].setText(""); //and set to empty
                            return;
                        }
                    }
                } else {
                    //for all other keyboard buttons
                    //get the button clicked
                    String letter = e.getKeyChar() + "";
                    //change it to upper case letter
                    letter = letter.toUpperCase();
                    //get its ascii
                    int ascii = (int) letter.charAt(0);
                    //make sure the clicked button is an alphabet
                    if (ascii >= 65 && ascii <= 97) {
                        for (int a = 0; a < text[index].length; a++) {
                            //find the empty place in the row
                            if (text[index][a].getText().equals("")) {
                                text[index][a].setText(letter); //set the letter at the empty place found
                                return;
                            }
                        }
                    }
                }
            }
        }

        //we dont need these two methods but they area craeted by default when we implement KeyListener
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }
}
